file = open("F:\\CSE221\\Assignment 6\\task1_input.txt", "r")
file1 = open("F:\\CSE221\\Assignment 6\\task1_output.txt", "w")

assignments = int(file.readline())

list1 = []
for line in file:
    line = line.split(" ")
    start_time = int(line[0])
    end_time = int(line[1])
    a = [start_time, end_time]
    list1.append(a)

class PriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, ele):
        self.queue.append(ele)
        min = self.queue[0][1]
        min_index = 0
        constant = min
        for i in range(len(self.queue)):
            if self.queue[i][1] < min:
                min = self.queue[i][1]
                min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]

    def dequeue(self):
        ret = self.queue[0]
        self.queue.pop(0)
        if len(self.queue) != 0:
            min = self.queue[0]
            min_index = 0
            constant = min
            for i in range(len(self.queue)):
                if self.queue[i][1] < min[1]:
                    min = self.queue[i]
                    min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]
        return ret

q = PriorityQueue()
for i in list1:
    q.enqueue(i)

w = []
a = q.dequeue()
w.append(a)

while len(q.queue) != 0:
    p = q.dequeue()
    if p[0] < w[-1][1]:
        continue
    else:
        w.append(p)

total = len(w)
file1.write(str(total) + "\n")
for i in w:
    string = str(i[0]) + " " + str(i[1]) + "\n"
    file1.write(string)

file.close()
file1.close()