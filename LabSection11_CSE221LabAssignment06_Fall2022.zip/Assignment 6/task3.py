file = open("F:\\CSE221\\Assignment 6\\task3_input.txt", "r")
file1 = open("F:\\CSE221\\Assignment 6\\task3_output.txt", "w")

noworktodo = file.readline()
work = file.readline().split(" ")
string = file.readline()

for i in range(len(work)):
    work[i] = int(work[i])

class MinPriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, ele):
        self.queue.append(ele)
        min = self.queue[0]
        min_index = 0
        constant = min
        for i in range(len(self.queue)):
            if self.queue[i] < min:
                min = self.queue[i]
                min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]

    def dequeue(self):
        ret = self.queue[0]
        self.queue.pop(0)
        if len(self.queue) != 0:
            min = self.queue[0]
            min_index = 0
            constant = min
            for i in range(len(self.queue)):
                if self.queue[i] < min:
                    min = self.queue[i]
                    min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]
        return ret

class MaxPriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, ele):
        self.queue.append(ele)
        min = self.queue[0]
        min_index = 0
        constant = min
        for i in range(len(self.queue)):
            if self.queue[i] > min:
                min = self.queue[i]
                min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]

    def dequeue(self):
        ret = self.queue[0]
        self.queue.pop(0)
        if len(self.queue) != 0:
            min = self.queue[0]
            min_index = 0
            constant = min
            for i in range(len(self.queue)):
                if self.queue[i] > min:
                    min = self.queue[i]
                    min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]
        return ret

work_list = MinPriorityQueue()
for i in work:
    work_list.enqueue(i)

jack = MaxPriorityQueue()
j = []
jill = []
output = ""

for char in string:
    if char == "J":
        w = work_list.dequeue()
        j.append(w)
        jack.enqueue(w)
        output += str(w)
    else:
        w = jack.dequeue()
        jill.append(w)
        output += str(w)

count1 = 0
count2 = 0

for i in j:
    count1 += i

for i in jill:
    count2 += i

file1.write(output + "\n")
str1 = "Jack will work for " + str(count1) + " hours"
str2 = "Jill will work for " + str(count2) + " hours"
file1.write(str1 + "\n")
file1.write(str2)

file.close()
file1.close()