file = open("F:\\CSE221\\Assignment 6\\task4_input.txt", "r")
file1 = open("F:\\CSE221\\Assignment 6\\task4_output.txt", "w")

for line in file:
    line = line.split(" ")
    for k in range(len(line)):
        line[k] = int(line[k])
    if line[0] == 0 and line[1] == 0:
        break
    else:
        start = int(line[0])
        end = int(line[1])
        count = 0
        for i in range(start, end + 1):
            j = 1
            while j * j <= i:
                if j * j == i:
                    count += 1
                j += 1
            i += 1
        file1.write(str(count) + "\n")

file.close()
file1.close()