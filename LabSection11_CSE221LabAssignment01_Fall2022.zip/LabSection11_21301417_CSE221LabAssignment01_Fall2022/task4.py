file = open("F:\\CSE221\\Lab Assignment 1\\input4.txt", "r")
file1 = open("F:\\CSE221\\Lab Assignment 1\\output4.txt", "w")
test_case = int(file.readline())
temp = file.readline()
id_list = temp.split(" ")
temp1 = file.readline()
mark_list = temp1.split(" ")

# We picked Selection Sort as it will swap only n number of times, whereas Insertion or Bubble Sort swaps (n^2) times
for i in range(test_case):
    max = i
    for j in range(i + 1, test_case):
        if mark_list[max] == mark_list[j]:
            if id_list[max] > id_list[j]:
                max = j
        elif mark_list[max] < mark_list[j]:
            max = j
    mark_list[i], mark_list[max] = mark_list[max], mark_list[i]
    id_list[i], id_list[max] = id_list[max], id_list[i]
for i in range(test_case):
    newline = "ID: " + str(int(id_list[i])) + " Mark: " + str(int(mark_list[i])) + "\n"
    file1.write(newline)
file.close()
file1.close()