file = open("F:\\CSE221\\Lab Assignment 1\\input3.txt", "r")
file1 = open("F:\\CSE221\\Lab Assignment 1\\output3.txt", "w")
size = int(file.readline())
temp = file.readline()
arr = temp.split(" ")
for i in range(size):
    arr[i] = int(arr[i])
def bubbleSort(array, length):
    for i in range(length - 1):
        # We are keeping a counter to count the number of times elements getting swapped
        # If the counter stays 0 after an iteration, then we can say that the list is sorted
        # If the counter stays 0 after the first iteration, then the list was already sorted
        # That leaves us with the best case, where the time complexity would be O(n) as the loop will go through n number of elements once
        counter = 0
        for j in range(length- i - 1):
            if array[j] > array[j + 1]:
                array[j], array[j + 1] = array[j + 1], array[j]
                counter += 1
        if counter == 0:
            break
bubbleSort(arr, size)
newline = ""
for i in arr:
    newline += str(i) + " "
file1.write(newline)
file.close()
file1.close()