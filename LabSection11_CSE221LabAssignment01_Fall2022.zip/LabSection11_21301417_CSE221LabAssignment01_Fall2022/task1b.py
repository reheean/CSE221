file = open("F:\\CSE221\\Lab Assignment 1\\input1b.txt", "r")
file1 = open("F:\\CSE221\\Lab Assignment 1\\output1b.txt", "w")
test_case = int(file.readline())
for i in range(test_case):
    temp = file.readline()
    string = temp.split(" ")
    if string[2] == "+":
        result = int(string[1]) + int(string[3])
        newline = "The result of " + string[1] + " " +string[2] + " " + str(int(string[3])) + " is " + str(result) + "\n"
    elif string[2] == "-":
        result = int(string[1]) - int(string[3])
        newline = "The result of " + string[1] + " " + string[2] + " " + str(int(string[3])) + " is " + str(result) + "\n"
    elif string[2] == "*":
        result = int(string[1]) * int(string[3])
        newline = "The result of " + string[1] + " " + string[2] + " " + str(int(string[3])) + " is " + str(result) + "\n"
    else:
        result = int(string[1]) / int(string[3])
        newline = "The result of " + string[1] + " " + string[2] + " " + str(int(string[3])) + " is " + str(result) + "\n"
    file1.writelines(newline)
file.close()
file1.close()