file = open("F:\\CSE221\\Lab Assignment 1\\input1a.txt", "r")
file1 = open("F:\\CSE221\\Lab Assignment 1\\output1a.txt", "w")
test_case = int(file.readline())
for i in range(test_case):
    if i != test_case - 1:
        temp = int(file.readline())
        if temp % 2 == 0:
            newline = str(temp) + ' is an Even number.\n'
        else:
            newline = str(temp) + ' is an Odd number.\n'
    else:
        temp = int(file.readline())
        if temp % 2 == 0:
            newline = str(temp) + ' is an Even number.'
        else:
            newline = str(temp) + ' is an Odd number.'
    file1.writelines(newline)
file.close()
file1.close()