file = open("F:\\CSE221\\Lab Assignment 1\\input5.txt", "r")
file1 = open("F:\\CSE221\\Lab Assignment 1\\output5.txt", "w")
size = int(file.readline())
info = []
for i in range(size):
    string = file.readline()
    mini_list = string.split(" ")
    info.append(mini_list)
name = []
for i in info:
    name.append(i[0].lower())
for i in range(size - 1):
    for j in range(size - i - 1):
        if name[j] == name[j + 1]:
            vari = info[j]
            varj = info[j + 1]
            time1 = vari[6].split(":")
            time2 = varj[6].split(":")
            if int(time1[0]) < int(time2[0]):
                name[j], name[j + 1] = name[j + 1], name[j]
                info[j], info[j + 1] = info[j + 1], info[j]
            elif int(time1[0]) == int(time2[0]):
                if int(time1[1]) < int(time2[1]):
                    name[j], name[j + 1] = name[j + 1], name[j]
                    info[j], info[j + 1] = info[j + 1], info[j]
        else:
            vark = name[j]
            varl = name[j + 1]
            if ord(vark[0]) == ord(varl[0]):
                if len(name[j]) == len(name[j + 1]):
                    v1 = name[j]
                    v2 = name[j + 1]
                    if ord(v1[-1]) > ord(v2[-1]):
                        name[j], name[j + 1] = name[j + 1], name[j]
                        info[j], info[j + 1] = info[j + 1], info[j]
                else:
                    min = None
                    big = None
                    if len(name[j]) > len(name[j + 1]):
                        min = len(name[j + 1])
                        big = name[j]
                    else:
                        min = len(name[j])
                        big = name[j + 1]
                    var1 = name[j]
                    var2 = name[j + 1]
                    if ord(var1[min - 1]) > ord(var2[min - 1]):
                        name[j], name[j + 1] = name[j + 1], name[j]
                        info[j], info[j + 1] = info[j + 1], info[j]
                    elif ord(var1[min - 1]) == ord(var2[min - 1]):
                        if var1 == big:
                            name[j], name[j + 1] = name[j + 1], name[j]
                            info[j], info[j + 1] = info[j + 1], info[j]
            elif ord(vark[0]) > ord(varl[0]):
                name[j], name[j + 1] = name[j + 1], name[j]
                info[j], info[j + 1] = info[j + 1], info[j]

for i in info:
    newline = i[0] + " " + i[1] + " " + " " + i[2] + " " + i[3] + " " + i[4] + " " + i[5] + " " + i[6]
    file1.write(newline)
file.close()
file1.close()