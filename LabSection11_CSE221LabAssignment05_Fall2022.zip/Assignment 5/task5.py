file = open("F:\\CSE221\\Assignment 5\\input5.txt", "r")
file1 = open("F:\\CSE221\\Assignment 5\\output5.txt", "w")

import sys
inf = sys.maxsize
matrix = []
sequence = []
device = []
relat = []
weigh = []
times = int(file.readline())

for line in file:
    temp = line
    temp = temp.split(" ")
    if len(temp) == 2:
        v = int(temp[0])
        e = int(temp[1])
        rel = []
        wei = []
        ver = []
        for i in range(e):
            l = file.readline()
            l = l.split(" ")
            if len(l) == 1:
                device.append(l[0])
            else:
                a = []
                a.append(l[0])
                a.append(l[1])
                rel.append(a)
                wei.append(int(l[2]))
                if l[0] and l[1] in ver:
                    continue
                elif l[0] in ver and l[1] not in ver:
                    ver.append(l[1])
                elif l[0] not in sequence and l[1] in sequence:
                    ver.append(l[0])
                else:
                    ver.append(l[0])
                    ver.append(l[1])
            if len(ver) == 0:
                ver.append("1")
            sequence.append(ver)
            relat.append(rel)
            weigh.append(wei)

def make_matrix(vertex_sequence, relation, weight):
    adj_matrix = []
    for i in range(len(vertex_sequence)):
        t = []
        for j in range(len(vertex_sequence)):
            t.append(None)
        adj_matrix.append(t)

    for i in range(len(vertex_sequence)):
        source = vertex_sequence[i]
        for j in range(len(relation)):
            if relation[j][0] != source:
                continue
            else:
                destination = relation[j][-1]
                ind = vertex_sequence.index(destination)
                adj_matrix[i][ind] = weight[j]
    return adj_matrix

for z in range(times):
    t1 = sequence[z]
    t2 = relat[z]
    t3 = weigh[z]
    m = make_matrix(t1, t2, t3)
    matrix.append(m)

class PriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, node, weight):
        temp = [node, weight]
        self.queue.append(temp)
        max = self.queue[0][1]
        max_index = 0
        constant = max
        for i in range(len(self.queue)):
            if self.queue[i][1] > max:
                max = self.queue[i][1]
                max_index = i
        if constant != max:
            self.queue[0], self.queue[max_index] = self.queue[max_index], self.queue[0]

    def dequeue(self):
        ret = self.queue[0]
        self.queue.pop(0)
        if len(self.queue) != 0:
            max = self.queue[0]
            max_index = 0
            constant = max
            for i in range(len(self.queue)):
                if self.queue[i][1] < max[1]:
                    max = self.queue[i]
                    max_index = i
            if constant != max:
                self.queue[0], self.queue[max_index] = self.queue[max_index], self.queue[0]
        return ret

def Network(sequence, graph, source):
    distance = [inf] * len(graph)
    distance[source] = inf
    prev = [None] * len(graph)
    q = PriorityQueue()
    for i in range(len(sequence)):
        q.enqueue(sequence[i], distance[i])
    while len(q.queue) != 0:
        u = q.dequeue()
        welp = sequence.index(u[0])
        for i in range(len(graph[welp])):
            if graph[welp][i] != None:
                alt = min(distance[welp], graph[welp][i])
                if alt > distance[i]:
                    distance[i] = alt
                    prev[i] = sequence[welp]
                    q.enqueue(sequence[i], distance[i])
    return distance, prev

for i in range(times):
    d1 = Network(sequence[i], matrix[i], device[i])
    parents = d1[1]
    cost = d1[0]
    destination = sequence[i].index(device[i])
    par_list = []
    while parents[destination] != None:
        ty = parents[destination]
        par_list.append(ty)
        te = sequence[i].index(ty)
        destination = te

    par_list.reverse()
    path = ""
    if len(par_list) == 0:
        path += "1"
    else:
        for j in range(len(par_list)):
            path = path + par_list[j] + " "
        path += device[i]


    file1.write(path + "\n")

file.close()
file1.close()