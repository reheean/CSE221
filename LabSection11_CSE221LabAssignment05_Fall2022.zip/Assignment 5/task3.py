file = open("F:\\CSE221\\Assignment 5\\input2.txt", "r")
file1 = open("F:\\CSE221\\Assignment 5\\output3.txt", "w")

import sys
inf = sys.maxsize
matrix = []
sequence = []
home = []
relat = []
weigh = []
times = int(file.readline())

for line in file:
    temp = line
    temp = temp.split(" ")
    if len(temp) == 2:
        h = int(temp[0])
        r = int(temp[1])
        home.append(str(h))
        rel = []
        wei = []
        ver = []
        for i in range(r):
            l = file.readline()
            l = l.split(" ")
            a = []
            a.append(l[0])
            a.append(l[1])
            rel.append(a)
            wei.append(int(l[2]))
            if l[0] and l[1] in ver:
                continue
            elif l[0] in ver and l[1] not in ver:
                ver.append(l[1])
            elif l[0] not in sequence and l[1] in sequence:
                ver.append(l[0])
            else:
                ver.append(l[0])
                ver.append(l[1])
        if len(ver) == 0:
            ver.append("1")
        sequence.append(ver)
        relat.append(rel)
        weigh.append(wei)

def make_matrix(vertex_sequence, relation, weight):
    adj_matrix = []
    for i in range(len(vertex_sequence)):
        t = []
        for j in range(len(vertex_sequence)):
            t.append(None)
        adj_matrix.append(t)

    for i in range(len(vertex_sequence)):
        source = vertex_sequence[i]
        for j in range(len(relation)):
            if relation[j][0] != source:
                continue
            else:
                destination = relation[j][-1]
                ind = vertex_sequence.index(destination)
                adj_matrix[i][ind] = weight[j]
    return adj_matrix

for z in range(times):
    t1 = sequence[z]
    t2 = relat[z]
    t3 = weigh[z]
    m = make_matrix(t1, t2, t3)
    matrix.append(m)

class PriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, node, weight):
        temp = [node, weight]
        self.queue.append(temp)
        min = self.queue[0][1]
        min_index = 0
        constant = min
        for i in range(len(self.queue)):
            if self.queue[i][1] < min:
                min = self.queue[i][1]
                min_index = i
        if constant != min:
            self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]

    def dequeue(self):
        ret = self.queue[0]
        self.queue.pop(0)
        if len(self.queue) != 0:
            min = self.queue[0]
            min_index = 0
            constant = min
            for i in range(len(self.queue)):
                if self.queue[i][1] < min[1]:
                    min = self.queue[i]
                    min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]
        return ret

def Dijkstra(sequence, graph, source):
    distance = [inf] * len(graph)
    ind = sequence.index(source)
    distance[ind] = 0
    visited = [0] * len(graph)
    prev = [None] * len(graph)
    q = PriorityQueue()
    for i in range(len(sequence)):
        q.enqueue(sequence[i], distance[i])
    while len(q.queue) != 0:
        u = q.dequeue()
        welp = sequence.index(u[0])
        if visited[welp]:
            continue
        visited[welp] = 1
        for i in range(len(graph[welp])):
            if graph[welp][i] != None:
                alt = distance[welp] + graph[welp][i]
                if alt < distance[i]:
                    distance[i] = alt
                    prev[i] = sequence[welp]
                    q.enqueue(sequence[i], distance[i])
    return distance, prev

for i in range(times):
    d1 = Dijkstra(sequence[i], matrix[i], "1")
    parents = d1[1]
    cost = d1[0]
    destination = sequence[i].index(home[i])
    par_list = []
    while parents[destination] != None:
        ty = parents[destination]
        par_list.append(ty)
        te = sequence[i].index(ty)
        destination = te

    par_list.reverse()
    path = ""
    if len(par_list) == 0:
        path += "1"
    else:
        for j in range(len(par_list)):
            path = path + par_list[j] + " "
        path += home[i]


    file1.write(path + "\n")

file.close()
file1.close()