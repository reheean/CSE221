file = open("F:\\CSE221\\Assignment 5\\input1.txt", "r")
file1 = open("F:\\CSE221\\Assignment 5\\output1.txt", "w")

import sys
inf = sys.maxsize
vertex_sequence = []
relation = []
weight = []

for line in file:
    tem = line
    tem = tem.split(" ")
    a = []
    a.append(tem[0])
    a.append(tem[1])
    relation.append(a)
    weight.append(int(tem[2]))
    if tem[0] and tem[1] in vertex_sequence:
        continue
    elif tem[0] in vertex_sequence and tem[1] not in vertex_sequence:
        vertex_sequence.append(tem[1])
    elif tem[0] not in vertex_sequence and tem[1] in vertex_sequence:
        vertex_sequence.append(tem[0])
    else:
        vertex_sequence.append(tem[0])
        vertex_sequence.append(tem[1])

adj_matrix = []
for i in range(len(vertex_sequence)):
    t = []
    for j in range(len(vertex_sequence)):
        t.append(None)
    adj_matrix.append(t)

for i in range(len(vertex_sequence)):
    source = vertex_sequence[i]
    for j in range(len(vertex_sequence)):
        if relation[j][0] != source:
            continue
        else:
            destination = relation[j][-1]
            ind = vertex_sequence.index(destination)
            adj_matrix[i][ind] = weight[j]


class PriorityQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, node, weight):
        temp = [node, weight]
        self.queue.append(temp)
        min = self.queue[0][1]
        min_index = 0
        constant = min
        for i in range(len(self.queue)):
            if self.queue[i][1] < min:
                min = self.queue[i][1]
                min_index = i
        if constant != min:
            self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]

    def dequeue(self):
        ret = self.queue[0]
        self.queue.pop(0)
        if len(self.queue) != 0:
            min = self.queue[0]
            min_index = 0
            constant = min
            for i in range(len(self.queue)):
                if self.queue[i][1] < min[1]:
                    min = self.queue[i]
                    min_index = i
            if constant != min:
                self.queue[0], self.queue[min_index] = self.queue[min_index], self.queue[0]
        return ret


def Dijkstra(sequence, graph, source):
    distance = [inf] * len(graph)
    ind = sequence.index(source)
    distance[ind] = 0
    visited = [0] * len(graph)
    prev = [None] * len(graph)
    q = PriorityQueue()
    for i in range(len(sequence)):
        q.enqueue(sequence[i], distance[i])
    while len(q.queue) != 0:
        u = q.dequeue()
        welp = sequence.index(u[0])
        if visited[welp]:
            continue
        visited[welp] = 1
        for i in range(len(graph[welp])):
            if graph[welp][i] != None:
                alt = distance[welp] + graph[welp][i]
                if alt < distance[i]:
                    distance[i] = alt
                    prev[i] = sequence[welp]
                    q.enqueue(sequence[i], distance[i])
    return distance, prev


d1 = Dijkstra(vertex_sequence, adj_matrix, "Motijheel")
parents = d1[1]
cost = d1[0]
destination = vertex_sequence.index("MOGHBAZAR")
lc = cost[destination]
par_list = []
while parents[destination] != None:
    ty = parents[destination]
    par_list.append(ty)
    te = vertex_sequence.index(ty)
    destination = te

par_list.reverse()

path = ""
for i in range(len(par_list)):
    path = path + par_list[i] + " ---> "
path += "MOGHBAZAR"

path = "Shortest path from Motijheel to MOGHBAZAR is: " + path
l = "Least traffic level: " + str(lc)

file1.write(path + "\n")
file1.write(l)

file.close()
file1.close()

# BFS cannot handle the weights on the edges, that's why we are not using BFS algorithm.