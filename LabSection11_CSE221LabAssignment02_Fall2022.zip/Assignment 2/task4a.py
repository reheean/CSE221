file = open("F:\CSE221\Assignment 2\input4.txt", "r")
file1 = open("F:\CSE221\Assignment 2\output4a.txt", "w")

class queue:
    def __init__(self):
        self.namelist = []
        self.emergencelvl = []

    def enqueue(self, patient, emergencelvl):
        if len(self.namelist) == 0:
            self.namelist.append(patient)
            self.emergencelvl.append(emergencelvl)
        else:
            self.namelist.append(patient)
            self.emergencelvl.append(emergencelvl)
            for i in range((len(self.namelist)) - 1):
                counter = 0
                for j in range(len(self.namelist) - i - 1):
                    if self.emergencelvl[j] > self.emergencelvl[j + 1]:
                        self.emergencelvl[j], self.emergencelvl[j + 1] = self.emergencelvl[j + 1], self.emergencelvl[j]
                        self.namelist[j], self.namelist[j + 1] = self.namelist[j + 1], self.namelist[j]
                        counter += 1
                if counter == 0:
                    break

    def seeDoctor(self):
        self.emergencelvl.pop(0)
        return self.namelist.pop(0)

q = queue()
for line in file:
    if line == "see doctor\n":
        newline = q.seeDoctor() + '\n'
        file1.write(newline)
    else:
        temp = line.split(" ")
        name = temp[0]
        level = int(temp[1])
        q.enqueue(name, level)

file.close()
file1.close()