file = open("F:\CSE221\Assignment 2\input3(ii).txt", "r")
file1 = open("F:\CSE221\Assignment 2\output3(ii).txt", "w")
temp = file.readline()
temp_list = temp.split(" ")
list1 = []
for char in temp_list[2:]:
    list1.append(int(char))

key_list = []
for line in file:
    temp = line[2]
    key_list.append(int(temp))

def partition(array, low, high):
    pivot = array[high]
    i = low - 1

    for j in range(low, high):
        if int(array[j]) <= int(pivot):
            i += 1
    return i + 1

def findk(array, low, high, key):
    if low == high:
        if low == key:
            return array[low]
        else:
            return
    else:
        temp = partition(array, low, high)
        if temp == key:
            return array[temp]
        elif temp < key:
            return findk(array, temp + 1, high, key)
        else:
            return findk(array, low, temp - 1, key)


for num in key_list:
    a = findk(list1, 0, len(list1) - 1, num - 1)
    file1.write(str(a) + "\n")
file.close()
file1.close()