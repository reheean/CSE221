file = open("F:\\CSE221\\Assignment 2\\input2.txt", "r")
file1 = open("F:\\CSE221\\Assignment 2\\output2.txt", "w")
size = int(file.readline())
temp = file.readline()
list1 = temp.split(" ")

def merge(array, left, mid, right):
    n1 = mid - left + 1
    n2 = right - mid

    l_arr = [0] * n1
    r_arr = [0] * n2

    for i in range(n1):
        l_arr[i] = array[left + i]

    for j in range(n2):
        r_arr[j] = array[mid + 1 + j]

    i = 0
    j = 0
    k = left

    while i < n1 and j < n2:
        if int(l_arr[i]) <= int(r_arr[j]):
            array[k] = l_arr[i]
            i += 1
        else:
            array[k] = r_arr[j]
            j += 1
        k += 1

    while i < n1:
        array[k] = l_arr[i]
        i += 1
        k += 1
    while j < n2:
        array[k] = r_arr[j]
        j += 1
        k += 1

def merge_sort(array, left, right):
    if left == right:
        return
    mid = (left + right) // 2
    merge_sort(array, left, mid)
    merge_sort(array, mid + 1, right)
    merge(array, left, mid, right)

merge_sort(list1, 0, size - 1)
newline = ""
for i in list1:
    newline = newline + i + " "
file1.write(newline)
file.close()
file1.close()