file = open("F:\\CSE221\\Assignment 2\\input1.txt", "r")
file1 = open("F:\\CSE221\\Assignment 2\\output1.txt", "w")
size = file.readline()
temp1 = file.readline()
ID = temp1.split(" ")
temp2 = file.readline()
Mark = temp2.split(" ")
for i in range(int(size) - 2):
  temp3 = Mark[i + 1]
  temp4 = ID[i + 1]
  j = i
  while j >= 0:
    if Mark[j] < temp3:
      Mark[j + 1] = Mark[j]
      ID[j + 1] = ID[j]
    else:
      break
    j -= 1
  Mark[j + 1] = temp3
  ID[j + 1] = temp4

ID_string = ''
for i in ID:
  ID_string = ID_string + i + ' '
file1.writelines(ID_string)
file.close()
file1.close()