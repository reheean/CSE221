file = open("F:\\CSE221\\Assignment 2\\input2.txt", "r")
file1 = open("F:\\CSE221\\Assignment 2\\output3(i).txt", "w")
size = int(file.readline())
temp = file.readline()
list1 = temp.split(" ")

def partition(array, low, high):
    pivot = array[high]
    i = low - 1

    for j in range(low, high):
        if int(array[j]) <= int(pivot):
            i += 1
            array[i], array[j] = array[j], array[i]
    array[i + 1], array[high] = array[high], array[i + 1]
    return i + 1

def quick_sort(array, low, high):
    if low < high:
        pi = partition(array, low, high)
        quick_sort(array, low, pi - 1)
        quick_sort(array, pi + 1, high)

quick_sort(list1, 0, (size - 1))

newline = ""
for i in list1:
    newline = newline + str(i) + " "
file1.write(newline)

file.close()
file1.close()