file = open("F:\CSE221\Assignment 2\input4.txt", "r")
file1 = open("F:\CSE221\Assignment 2\output4a.txt", "w")

class queue:
    def __init__(self):
        self.namelist = []
        self.emergencelvl = []

    def enqueue(self, patient, emergencelvl):
        if len(self.namelist) == 0:
            self.namelist.append(patient)
            self.emergencelvl.append(emergencelvl)
        else:
            self.namelist.append(patient)
            self.emergencelvl.append(emergencelvl)
            for i in range((len(self.namelist)) - 1):
                counter = 0
                for j in range(len(self.namelist) - i - 1):
                    if self.emergencelvl[j] > self.emergencelvl[j + 1]:
                        self.emergencelvl[j], self.emergencelvl[j + 1] = self.emergencelvl[j + 1], self.emergencelvl[j]
                        self.namelist[j], self.namelist[j + 1] = self.namelist[j + 1], self.namelist[j]
                        counter += 1
                if counter == 0:
                    break

    def seeDoctor(self):
        self.emergencelvl.pop(0)
        return self.namelist.pop(0)

q = queue()
for line in file:
    if line == "see doctor\n":
        newline = q.seeDoctor() + '\n'
        file1.write(newline)
    else:
        temp = line.split(" ")
        name = temp[0]
        level = int(temp[1])
        q.enqueue(name, level)

file.close()
file1.close()




file = open("F:\CSE221\Assignment 2\input4.txt", "r")
file1 = open("F:\CSE221\Assignment 2\output4b.txt", "w")

class heap:
    def __init__(self):
        self.heap = []
        self.name = []

    def heapify(self, num, idx):
        mini = idx
        l = 2 * idx + 1
        r = 2 * idx + 2

        if l > num and self.heap[idx] < self.heap[l]:
            mini = l

        if r > num and self.heap[mini] < self.heap[r]:
            mini = r

        if mini != idx:
            self.heap[idx], self.heap[mini] = self.heap[mini], self.heap[idx]
            self.name[idx], self.heap[mini] = self.heap[mini], self.heap[idx]
            self.heapify(num, mini)

    def sink(self, num, idx):
        maxx = idx
        l = 2 * idx + 1
        r = 2 * idx + 2

        if l > num and self.heap[idx] > self.heap[l]:
            mini = l

        if r > num and self.heap[maxx] > self.heap[r]:
            maxx = r

        if maxx != idx:
            self.heap[idx], self.heap[maxx] = self.heap[maxx], self.heap[idx]
            self.name[idx], self.heap[maxx] = self.heap[maxx], self.heap[idx]
            self.heapify(num, maxx)

    def insert(self, name, level):
        if len(self.heap) == 0:
            self.heap.append(level)
            self.name.append(name)
        else:
            self.heap.append(level)
            self.name.append(name)
            for idx in range((len(self.heap) // 2) - 1, -1, -1):
                self.heapify(len(self.heap), idx)

    def seeDoctor(self):
        name = self.name[0]
        last1 = self.heap[len(self.heap) - 1]
        last2 = self.name[len(self.name) - 1]
        self.name.pop(len(self.heap) - 1)
        self.heap.pop(len(self.heap) - 1)
        self.name[0] = last2
        self.heap[0] = last1

        for i in range((len(self.heap) // 2) - 1, -1, -1):
            self.sink(len(self.heap), i)
        return name

h = heap()
for line in file:
    if line == "see doctor\n":
        #newline = h.seeDoctor() + '\n'
        #file1.write(newline)
        continue
    else:
        temp = line.split(" ")
        name = temp[0]
        level = int(temp[1])
        h.insert(name, level)

file.close()
file1.close()















import time
import math
import matplotlib.pyplot as plt
import numpy as np
#change the value of n for your own experimentation
n = 30
x = [i for i in range(n)]
y = [0 for i in range(n)]
z = [0 for i in range(n)]
for i in range(n-1):
    start = time.time()
    q(x[i+1])
    y[i+1]= time.time()-start
    start = time.time()
    h(x[i+1])
    z[i+1]= time.time()-start
x_interval = math.ceil(n/10)
plt.plot(x, y, 'r')
plt.plot(x, z, 'b')
plt.xticks(np.arange(min(x), max(x)+1, x_interval))
plt.xlabel('n-th position')
plt.ylabel('time')
plt.title('Comparing Time Complexity!')
plt.show()