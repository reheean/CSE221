file = open("F:\\CSE221\\Assignment 3\\input1a_2.txt", "r")
file1 = open("F:\\CSE221\\Assignment 3\\output1a_2.txt", "w")
temp = file.readline()
temp = temp.split(" ")
vertex = int(temp[0])
edge = int(temp[-1])
list1 = []
for i in range(vertex + 1):
  t = []
  for j in range(vertex + 1):
    t.append(0)
  list1.append(t)

for line in file:
  temp = line.split(" ")
  source = int(temp[0])
  destination = int(temp[1])
  list1[source][destination] = int(temp[2])

for i in list1:
  file1.write(str(i) + "\n")

file.close()
file1.close()