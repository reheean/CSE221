file = open("F:\\CSE221\\Assignment 3\\input3_3.txt", "r")
file1 = open("F:\\CSE221\\Assignment 3\\output3_3.txt", "w")

temp = file.readline()
temp = temp.split(" ")
nodes = int(temp[0])
edges = int(temp[1])

list1 = []
for i in range(nodes + 1):
    t = []
    list1.append(t)

for line in file:
    temp = line.split(" ")
    source = int(temp[0])
    destination = int(temp[1])
    list1[source].append(destination)

def DFS(graph, source):
    stack = [source]
    color = [0] * (len(graph) + 1)
    sequence = []
    while len(stack) != 0:
        node = stack.pop()
        if color[node] == 0:
            color[node] = 1
            sequence.append(node)
            [stack.append(x) for x in graph[node]]

    string = ''
    for i in sequence:
        string += str(i) + " "
    return string

path = DFS(list1, 1)
file1.write(path)

file.close()
file1.close()