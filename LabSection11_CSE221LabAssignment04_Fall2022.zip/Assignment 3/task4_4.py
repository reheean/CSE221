file = open("F:\\CSE221\\Assignment 3\\input4_4.txt", "r")
file1 = open("F:\\CSE221\\Assignment 3\\output4_4.txt", "w")

temp = file.readline()
temp = temp.split(" ")
nodes = int(temp[0])
edges = int(temp[1])


list1 = []
color = []
for i in range(nodes + 1):
    t = []
    list1.append(t)
    color.append(t)

for line in file:
    temp = line.split(" ")
    source = int(temp[0])
    destination = int(temp[1])
    list1[source].append(destination)
    color[source] = "White"

def checkCycle(u, color):
    color[u] = "Grey"
    for v in list1[u]:
        if color[v] == "White":
            temp = checkCycle(v, color)
            if temp is True:
                return True
        elif color[v] == "Grey":
            return True
    color[u] = "Black"
    return False

result = False
for node in range(len(list1)):
    if color[node] == "White":
        result = checkCycle(node, color)
        if result is True:
            break

if result is True:
    file1.write("YES")
else:
    file1.write("NO")

# 4a
# if there is no cross edge or any back edge, there is a tree

# 4b
# we have to keep track of parent nodes as we cycle through the graph
# then if we find a loop, we will have to trace back to the parent node
# then we have to count the number of vertices in the loop
# in this way, we will find the odd length cycle

file.close()
file1.close()