file = open("F:\\CSE221\\Assignment 3\\input1b_3.txt", "r")
file1 = open("F:\\CSE221\\Assignment 3\\output1b_3.txt", "w")

class Node:
  def __init__(self, vertex, weight):
    self.vertex = vertex
    self.weight = weight

temp = file.readline()
temp = temp.split(" ")
vert = int(temp[0])
edge = int(temp[-1])
list1 = []
for i in range(vert + 1):
  t = []
  list1.append(t)

for line in file:
  temp = line.split(" ")
  source = int(temp[0])
  destination = int(temp[1])
  weight = int(temp[-1])
  list1[source].append(Node(destination, weight))

for i in range(len(list1)):
  newline = str(i) + ": "
  for j in list1[i]:
    temp = "(" + str(j.vertex) + ", " + str(j.weight) + ") "
    newline += temp
  file1.write(newline + "\n")


file.close()
file1.close()

# 1B_a

# For an undirected graph, we will have to modify in a way that
# we make sure we can come from destination vertex to source vertex
# the modified code will be in the following way
#for line in file:
  #temp = line.split(" ")
  #source = int(temp[0])
  #destination = int(temp[1])
  #weight = int(temp[-1])
  #list1[source].append(Node(destination, weight))
  #list1[destination].append(Node(source, weight))

# 1B_b

# No it is not possible to represent parallel edges in an adjacency matrix