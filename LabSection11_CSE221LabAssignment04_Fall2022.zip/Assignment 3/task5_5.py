file = open("F:\\CSE221\\Assignment 3\\input5_5.txt", "r")
file1 = open("F:\\CSE221\\Assignment 3\\output5_5.txt", "w")

temp = file.readline()
temp = temp.split(" ")
nodes = int(temp[0])
edges = int(temp[1])
end = int(temp[-1])

list1 = []
for i in range(nodes + 1):
    t = []
    list1.append(t)

for line in file:
    temp = line.split(" ")
    source = int(temp[0])
    destination = int(temp[1])
    list1[source].append(destination)

def shortestTime(graph, source, destination):
    min_time = 0
    if source == destination:
        return 0
    else:
        queue = [source]
        color = [0] * (len(graph) + 1)
        color[source] = 1
        while len(queue) != 0:
            size = len(queue)
            while size > 0:
                temp = queue.pop(0)
                for node in graph[temp]:
                    if node == destination:
                        min_time += 1
                        return min_time
                    if color[node] == 0:
                        queue.append(node)
                        color[node] = 1
                size -= 1
            min_time += 1
        return -1

time = shortestTime(list1, 1, end)
file1.write("Time: " + str(time))
file.close()
file1.close()