file = open("F:\\CSE221\\Assignment 7\\task2_input.txt", "r")
file1 = open("F:\\CSE221\\Assignment 7\\task2_output.txt", "w")

zones = int(file.readline())
sequence = file.readline()
prediction = file.readline()
poi = {"Y": "Yasnaya", "P": "Pochinki", "S": "School", "R": "Rozhok", "F": "Farm", "M": "Mylta", "H": "Shelter", "I": "Prison"}

def LCS(string1, string2):
    m = len(string1)
    n = len(string2)

    array = []
    for i in range(m + 1):
        temp = [0] * (n + 1)
        array.append(temp)

    for p in range(m + 1):
        for q in range(n + 1):
            if p == 0 or q == 0:
                array[p][q] = 0
            elif string1[p - 1] == string2[q - 1]:
                array[p][q] = array[p - 1][q - 1] + 1
            else:
                array[p][q] = max(array[p - 1][q], array[p][q - 1])

    output = ""
    l1 = m
    l2 = n
    while l1 > 0 and l2 > 0:
        if string1[l1 - 1] == string2[l2 - 1]:
            output += string1[l1 - 1]
            l1 -= 1
            l2 -= 1
        elif array[l1 - 1][l2] > array[l1][l2 - 1]:
            l1 -= 1
        else:
            l2 -= 1

    return output

lcs = LCS(sequence, prediction)
temp = ""
for i in lcs:
    place = poi.get(i)
    temp = place + " " + temp

file1.write(temp + "\n")
correctness = int((len(lcs) * 100) / zones)
file1.write("Correctness of prediction: " + str(correctness) + "%")

file.close()
file1.close()