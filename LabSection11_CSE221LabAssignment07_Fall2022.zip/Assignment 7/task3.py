file = open("F:\\CSE221\\Assignment 7\\task3_input.txt", "r")
file1 = open("F:\\CSE221\\Assignment 7\\task3_output.txt", "w")

string1 = file.readline()
string2 = file.readline()
string3 = file.readline()

def LCS(x, y, z):
    m = len(x)
    n = len(y)
    o = len(z)
    array = [[[0 for i in range(o + 1)] for j in range(n + 1)] for k in range(m + 1)]

    for i in range(m + 1):
        for j in range(n + 1):
            for k in range(o + 1):
                if i == 0 or j == 0 or k == 0:
                    array[i][j][k] = 0
                elif x[i - 1] == y[j - 1] and x[i - 1] == z[k - 1]:
                    array[i][j][k] = array[i - 1][j - 1][k - 1] + 1
                else:
                    array[i][j][k] = max(max(array[i - 1][j][k], array[i][j - 1][k]), array[i][j][k - 1])

    return array[m][n][o]

lcs = LCS(string1, string2, string3)
file1.write(str(lcs))

file.close()
file1.close()