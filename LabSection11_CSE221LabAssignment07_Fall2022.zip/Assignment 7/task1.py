file = open("F:\\CSE221\\Assignment 7\\task1_input.txt", "r")
file1 = open("F:\\CSE221\\Assignment 7\\task1_output.txt", "w")

num = int(file.readline())
output_list = []
while num != 0:
    temp = str(num)
    output_list.append(temp)
    temp_list = []
    for i in temp:
        temp_list.append(int(i))
    maxi = temp_list[0]
    for i in range(len(temp_list)):
        if temp_list[i] > maxi:
            maxi = temp_list[i]
    num = num - maxi

output_list.append("0")

for i in range(len(output_list)):
    if i != len(output_list) - 1:
        file1.write(output_list[i])
        file1.write("--> ")
    else:
        file1.write(output_list[i])
        file1.write(".")

file.close()
file1.close()